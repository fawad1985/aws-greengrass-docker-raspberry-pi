exports.start = function start(runtime) {
    runtime.getWorkAndInvoke();
};
